using Microsoft.AspNetCore.Mvc;

namespace SimpleCalculatorApp.Controllers
{
    [Route("calculator")]
    public class CalculatorController : Controller
    {
        // Display form
        [HttpGet("")]
        public IActionResult Index()
        {
            return View();
        }

        // Handle form submission
        [HttpPost("calculate")]
        public IActionResult Calculate(IFormCollection form)
        {
            int num1 = Convert.ToInt32(form["num1"]);
            int num2 = Convert.ToInt32(form["num2"]);
            string operation = form["operation"];
            double result = 0;

            switch (operation)
            {
                case "Add":
                    result = num1 + num2;
                    break;

                case "Subtract":
                    result = num1 - num2;
                    break;

                case "Multiply":
                    result = num1 * num2;
                    break;

                case "Divide":
                    result = (double)num1 / num2;
                    break;
                    case "Percentage":
                    result = ((double)num1 / num2) * 100;
                    break;
            }

            ViewData["Result"] = result;
            ViewData["Operation"] = operation;

            return View("Index");
        }
    }
}