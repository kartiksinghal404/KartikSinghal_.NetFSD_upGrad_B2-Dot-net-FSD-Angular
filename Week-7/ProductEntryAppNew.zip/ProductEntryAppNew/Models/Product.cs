namespace ProductEntryAppNew.Models
{
    public class Product
    {
        public string ProductName { get; set; } = string.Empty;
        public decimal Price { get; set; }
        public int Quantity { get; set; }
    }
}