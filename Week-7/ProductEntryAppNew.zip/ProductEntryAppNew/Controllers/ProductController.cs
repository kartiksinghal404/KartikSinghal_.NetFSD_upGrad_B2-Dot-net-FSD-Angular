using Microsoft.AspNetCore.Mvc;
using ProductEntryAppNew.Models;
using ProductEntryAppNew.Helpers;
namespace ProductEntryAppNew.Controllers
{
    [Route("product")]
    public class ProductController : Controller
    {
        [HttpGet("")]
        [HttpGet("index")]
        public IActionResult Index()
        {
            var products = HttpContext.Session.GetObjectFromJson<List<Product>>("ProductList")
                           ?? new List<Product>();

            ViewBag.Products = products;

            return View();
        }

        [HttpPost("add")]
        public IActionResult Add(Product product)
        {
            var products = HttpContext.Session.GetObjectFromJson<List<Product>>("ProductList")
                           ?? new List<Product>();

            products.Add(product);

            HttpContext.Session.SetObjectAsJson("ProductList", products);

            ViewBag.Products = products;

            return View("Index");
        }
    }
}