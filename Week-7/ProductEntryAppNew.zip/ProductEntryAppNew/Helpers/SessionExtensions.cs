namespace ProductEntryAppNew.Helpers
{
    public static class SessionExtensions
    {
        public static void SetObjectAsJson(this Microsoft.AspNetCore.Http.ISession session, string key, object value)
        {
            session.SetString(key, System.Text.Json.JsonSerializer.Serialize(value));
        }

        public static T? GetObjectFromJson<T>(this Microsoft.AspNetCore.Http.ISession session, string key)
        {
            var value = session.GetString(key);

            return value == null
                ? default
                : System.Text.Json.JsonSerializer.Deserialize<T>(value);
        }
    }
}